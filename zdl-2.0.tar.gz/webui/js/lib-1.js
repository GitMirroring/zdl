//  ZigzagDownLoader (ZDL)
//
//  This program is free software: you can redistribute it and/or modify it
//  under the terms of the GNU General Public License as published
//  by the Free Software Foundation; either version 3 of the License,
//  or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
//  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program. If not, see http://www.gnu.org/licenses/.
//
//  Copyright (C) 2011: Gianluca Zoni (zoninoz) <zoninoz@inventati.org>
//
//  For information or to collaborate on the project:
//  https://savannah.nongnu.org/projects/zdl
//
//  Gianluca Zoni
//  http://inventati.org/zoninoz
//  zoninoz@inventati.org

var displayLinks = function (op) {
    var query = "cmd=get-data";
    var spec = {};
    spec.long_polling = true;

    if (op === "force")
        query += "&op=force";
    if (op === "stop") {
    	spec.long_polling = false;
        query += "&op=force";
    }
    
    ajax({
        query: query,
	params: spec,
        callback: function (str, spec) {
            if (isJsonString(str)) {
                var data = JSON.parse(str);
                var output = "";
                var visibility = "hidden";
                var color;

                for (var i = 0; i < data.length; i++) {
                    if (ZDL.visible[data[i].path + "-" + data[i].link])
                        visibility = "visible";
                    else
                        visibility = "hidden";


    		    if (data[i].downloader == "FFMpeg" &&
    			data[i].percent < 100 &&
    			data[i].color == "green")
    		    {
    			var op = "force";
    		    }
		    
		    output += "<div id='info-" + i + "-bar'>";

                    output += "<div id='progress-bar'>" +
                        "<div id='progress-label-file'>" + data[i].file + "</div>" +
                        "<div id='progress-status' style='width:" + data[i].percent + "%; background-color:" + data[i].color + "'></div>" +
                        "</div>";

                    output += "<div id='progress-label-status'>" +
                        data[i].percent + "% " +
                        parseFloat(data[i].speed).toFixed(2) + data[i].speed_measure + " " +
                        data[i].eta +
                        "</div>" +
                        "</div>";

                    output += "<div class='download-info " + visibility + "' id='info-" + i + "'>";

                    output += "<div class='label-element'>Downloader:</div>" +
			"<div class='element'><p>" + data[i].downloader + "</p></div>";

                    output += "<div class='label-element'>Link:</div>" +
			"<div class='element'><p>" + data[i].link + "</p></div>";

                    output += "<div class='label-element'>Path:</div>" +
			"<div class='element'><p>" + data[i].path + "</p>" +
			"<button class='btn' id='link-to-path-" + i + "'>Gestisci</button></div>";

                    output += "<div class='label-element'>File:</div>" +
			"<div class='element'><p>" + data[i].file + "</p><button class='btn' id='link-add-playlist-" + i + "'>Aggiungi alla playlist</button></div>";
		    
                    output += "<div class='label-element'>Length:</div>" +
			"<div class='element'><p>" + (data[i].length / 1024 / 1024).toFixed(2) +  "M</p></div>";

                    if (data[i].downloader.match(/^(RTMPDump|cURL)$/)) {
                        output += "<div class='label-element'>Streamer:</div>" +
                            "<div class='element'><p>" + data[i].streamer + "</p></div>";
                        output += "<div class='label-element'>Playpath:</div>" +
                            "<div class='element'><p>" + data[i].playpath + "</p></div>";
                    }
		    else {
                        output += "<div class='label-element'>Url:</div>" +
                            "<div class='element'><p>" + toHtmlEntities(data[i].url) + "</p></div>";
                    }

                    output += "<div class='background-element align-center'>" + displayLinkButtons(i);
                    output += "</div></div>";
                }

                document.getElementById("output-links").innerHTML = output;

                for (var i = 0; i < data.length; i++) {
                    onClick({
                        id: "link-add-playlist-" + i,
                        callback: function (file) {
                            addPlaylist(file);
                        },
                        params: data[i].path + "/" + data[i].file
                    });

                    onClick({
                        id: "play-" + i,
                        callback: function (data) {
                            singleLink(data).play();
                        },
                        params: data[i]
                    });

                    onClick({
                        id: "del-" + i,
                        callback: function (data) {
                            if (confirm("Vuoi davvero cancellare il download del file " + data.file + " ?")) {
                                singleLink(data).del();
                            }
                        },
                        params: data[i]
                    });

                    onClick({
                        id: "stop-" + i,
                        callback: function (data) {
                            singleLink(data).stop();
                        },
                        params: data[i]
                    });

                    onClick({
                        id: "link-to-path-" + i,
                        callback: sectionPath,
                        params: data[i].path
                    });

                    onClick({
                        id: "info-" + i + "-bar",
                        callback: showInfoLink,
                        params: {
                            id: "info-" + i,
                            key: data[i].path + "-" + data[i].link
                        }
                    });

                    onClick({
                        id: "info-" + i,
                        callback: hideInfoLink,
                        params: {
                            id: "info-" + i,
                            key: data[i].path + "-" + data[i].link
                        }
                    });
                }

		if (spec.long_polling === true)
                    return displayLinks(op);
		else
		    return true;

            } else {
		document.getElementById("output-links").innerHTML = "";

		if (spec.long_polling === true)
		    return displayLinks();
		else
		    return true;
	    }
        }
    });
};
