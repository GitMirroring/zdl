#!/bin/bash -i
#
# ZigzagDownLoader (ZDL)
# 
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published 
# by the Free Software Foundation; either version 3 of the License, 
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
# or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see http://www.gnu.org/licenses/. 
# 
# Copyright (C) 2011: Gianluca Zoni (zoninoz) <zoninoz@inventati.org>
# 
# For information or to collaborate on the project:
# https://savannah.nongnu.org/projects/zdl
# 
# Gianluca Zoni (author)
# http://inventati.org/zoninoz
# zoninoz@inventati.org
#

## conversione del link di xWeasel:
##
if [[ "$url_in" =~ ^xdcc://[^/]+/([^/]+)/([^/]+)/([^/]+)/([^/]+) ]]
then
    irc_chan="${BASH_REMATCH[2]##\#}"
    irc_chan="${irc_chan##\%23}"
    replace_url_in "$(sanitize_url "irc://${BASH_REMATCH[1]}/$irc_chan/msg ${BASH_REMATCH[3]} xdcc send ${BASH_REMATCH[4]}")"
fi

## link di ZDL:
##
if [[ "$url_in" =~ ^irc:\/\/ ]]
then
    xdcc_url_new="$(tr '[:upper:]' '[:lower:]' <<< "$(sanitize_url "$url_in")")"

    xdcc_url_new="${xdcc_url_new//openjoke.net/openjoke.org}"
    xdcc_url_new="${xdcc_url_new//artikanet.org/arabaphenix.it}"
    xdcc_url_new="${xdcc_url_new//openjoke.org\/tilt/williamgattone.it\/tilt}"
    xdcc_url_new="${xdcc_url_new//openjoke.org\/maleventum/williamgattone.it\/maleventum}"
    xdcc_url_new="${xdcc_url_new//openjoke.org\/serial-tv/arabaphenix.it\/serial-tv}"
    xdcc_url_new="${xdcc_url_new//openjoke.org\/william\&carola/williamgattone.it\/william\&carola}"

    replace_url_in "$xdcc_url_new"
    
    url_in_file="$url_in"
    downloader_in=DCC_Xfer
fi

